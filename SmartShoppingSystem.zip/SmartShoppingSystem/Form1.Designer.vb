﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        GroupBox1 = New GroupBox()
        cboMembership = New ListBox()
        txtCustomerName = New TextBox()
        Label3 = New Label()
        Label2 = New Label()
        GroupBox2 = New GroupBox()
        btnCalculateBill = New Button()
        btnAddItem = New Button()
        txtDiscountCode = New TextBox()
        txtQuantity = New TextBox()
        txtPrice = New TextBox()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        cboCategory = New ListBox()
        Label5 = New Label()
        txtProductName = New TextBox()
        Label4 = New Label()
        GroupBox3 = New GroupBox()
        lstCart = New ListBox()
        GroupBox4 = New GroupBox()
        lblPurchaseLevel = New Label()
        lblFinalTotal = New Label()
        lblTax = New Label()
        lblDiscount = New Label()
        lblSubtotal = New Label()
        Label13 = New Label()
        Label12 = New Label()
        Label11 = New Label()
        Label10 = New Label()
        Label9 = New Label()
        btnClear = New Button()
        btnExit = New Button()
        btnPrintSummary = New Button()
        btnRemoveItem = New Button()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        GroupBox3.SuspendLayout()
        GroupBox4.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = SystemColors.Control
        Label1.Font = New Font("Shonar Bangla", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.MenuHighlight
        Label1.Location = New Point(179, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(375, 37)
        Label1.TabIndex = 0
        Label1.Text = "Smart Shoppg Management System"
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(cboMembership)
        GroupBox1.Controls.Add(txtCustomerName)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Location = New Point(25, 76)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(319, 125)
        GroupBox1.TabIndex = 1
        GroupBox1.TabStop = False
        GroupBox1.Text = "Customer Info"
        ' 
        ' cboMembership
        ' 
        cboMembership.FormattingEnabled = True
        cboMembership.Items.AddRange(New Object() {"Regular", "Premium", "VIP"})
        cboMembership.Location = New Point(149, 70)
        cboMembership.Name = "cboMembership"
        cboMembership.Size = New Size(152, 24)
        cboMembership.TabIndex = 2
        ' 
        ' txtCustomerName
        ' 
        txtCustomerName.Location = New Point(149, 31)
        txtCustomerName.Name = "txtCustomerName"
        txtCustomerName.Size = New Size(152, 27)
        txtCustomerName.TabIndex = 2
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(48, 70)
        Label3.Name = "Label3"
        Label3.Size = New Size(95, 20)
        Label3.TabIndex = 1
        Label3.Text = "Membership:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(24, 34)
        Label2.Name = "Label2"
        Label2.Size = New Size(119, 20)
        Label2.TabIndex = 0
        Label2.Text = "Customer Name:"
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(btnCalculateBill)
        GroupBox2.Controls.Add(btnAddItem)
        GroupBox2.Controls.Add(txtDiscountCode)
        GroupBox2.Controls.Add(txtQuantity)
        GroupBox2.Controls.Add(txtPrice)
        GroupBox2.Controls.Add(Label8)
        GroupBox2.Controls.Add(Label7)
        GroupBox2.Controls.Add(Label6)
        GroupBox2.Controls.Add(cboCategory)
        GroupBox2.Controls.Add(Label5)
        GroupBox2.Controls.Add(txtProductName)
        GroupBox2.Controls.Add(Label4)
        GroupBox2.Location = New Point(417, 76)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(344, 289)
        GroupBox2.TabIndex = 2
        GroupBox2.TabStop = False
        GroupBox2.Text = "Product Info"
        ' 
        ' btnCalculateBill
        ' 
        btnCalculateBill.BackColor = Color.DarkCyan
        btnCalculateBill.Location = New Point(206, 243)
        btnCalculateBill.Name = "btnCalculateBill"
        btnCalculateBill.Size = New Size(94, 29)
        btnCalculateBill.TabIndex = 11
        btnCalculateBill.Text = "Calculate"
        btnCalculateBill.UseVisualStyleBackColor = False
        ' 
        ' btnAddItem
        ' 
        btnAddItem.BackColor = Color.DarkCyan
        btnAddItem.Location = New Point(93, 243)
        btnAddItem.Name = "btnAddItem"
        btnAddItem.Size = New Size(94, 29)
        btnAddItem.TabIndex = 10
        btnAddItem.Text = "Add Item"
        btnAddItem.UseVisualStyleBackColor = False
        ' 
        ' txtDiscountCode
        ' 
        txtDiscountCode.Location = New Point(143, 190)
        txtDiscountCode.Name = "txtDiscountCode"
        txtDiscountCode.Size = New Size(180, 27)
        txtDiscountCode.TabIndex = 9
        ' 
        ' txtQuantity
        ' 
        txtQuantity.Location = New Point(143, 149)
        txtQuantity.Name = "txtQuantity"
        txtQuantity.Size = New Size(180, 27)
        txtQuantity.TabIndex = 8
        ' 
        ' txtPrice
        ' 
        txtPrice.Location = New Point(143, 109)
        txtPrice.Name = "txtPrice"
        txtPrice.Size = New Size(180, 27)
        txtPrice.TabIndex = 7
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(28, 193)
        Label8.Name = "Label8"
        Label8.Size = New Size(109, 20)
        Label8.TabIndex = 6
        Label8.Text = "Discount Code:"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(69, 152)
        Label7.Name = "Label7"
        Label7.Size = New Size(68, 20)
        Label7.TabIndex = 5
        Label7.Text = "Quantity:"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(93, 112)
        Label6.Name = "Label6"
        Label6.Size = New Size(44, 20)
        Label6.TabIndex = 4
        Label6.Text = "Price:"
        ' 
        ' cboCategory
        ' 
        cboCategory.FormattingEnabled = True
        cboCategory.Items.AddRange(New Object() {"Electronic", "Toys", "Clothing", "Groceries", "Books", "Sports", "Home and Garden"})
        cboCategory.Location = New Point(143, 70)
        cboCategory.Name = "cboCategory"
        cboCategory.Size = New Size(180, 24)
        cboCategory.TabIndex = 3
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(65, 70)
        Label5.Name = "Label5"
        Label5.Size = New Size(72, 20)
        Label5.TabIndex = 2
        Label5.Text = "Category:"
        ' 
        ' txtProductName
        ' 
        txtProductName.Location = New Point(143, 31)
        txtProductName.Name = "txtProductName"
        txtProductName.Size = New Size(180, 27)
        txtProductName.TabIndex = 1
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(30, 34)
        Label4.Name = "Label4"
        Label4.Size = New Size(107, 20)
        Label4.TabIndex = 0
        Label4.Text = "Product Name:"
        ' 
        ' GroupBox3
        ' 
        GroupBox3.Controls.Add(btnRemoveItem)
        GroupBox3.Controls.Add(lstCart)
        GroupBox3.Location = New Point(25, 228)
        GroupBox3.Name = "GroupBox3"
        GroupBox3.Size = New Size(319, 332)
        GroupBox3.TabIndex = 3
        GroupBox3.TabStop = False
        GroupBox3.Text = "Shopping Cart"
        ' 
        ' lstCart
        ' 
        lstCart.FormattingEnabled = True
        lstCart.Location = New Point(6, 41)
        lstCart.Name = "lstCart"
        lstCart.Size = New Size(295, 244)
        lstCart.TabIndex = 0
        ' 
        ' GroupBox4
        ' 
        GroupBox4.Controls.Add(lblPurchaseLevel)
        GroupBox4.Controls.Add(lblFinalTotal)
        GroupBox4.Controls.Add(lblTax)
        GroupBox4.Controls.Add(lblDiscount)
        GroupBox4.Controls.Add(lblSubtotal)
        GroupBox4.Controls.Add(Label13)
        GroupBox4.Controls.Add(Label12)
        GroupBox4.Controls.Add(Label11)
        GroupBox4.Controls.Add(Label10)
        GroupBox4.Controls.Add(Label9)
        GroupBox4.Location = New Point(417, 391)
        GroupBox4.Name = "GroupBox4"
        GroupBox4.Size = New Size(344, 211)
        GroupBox4.TabIndex = 4
        GroupBox4.TabStop = False
        GroupBox4.Text = "Summary"
        ' 
        ' lblPurchaseLevel
        ' 
        lblPurchaseLevel.BackColor = SystemColors.ControlLight
        lblPurchaseLevel.BorderStyle = BorderStyle.Fixed3D
        lblPurchaseLevel.Location = New Point(121, 154)
        lblPurchaseLevel.Name = "lblPurchaseLevel"
        lblPurchaseLevel.Size = New Size(194, 25)
        lblPurchaseLevel.TabIndex = 9
        lblPurchaseLevel.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblFinalTotal
        ' 
        lblFinalTotal.BackColor = SystemColors.ControlLight
        lblFinalTotal.BorderStyle = BorderStyle.Fixed3D
        lblFinalTotal.Location = New Point(121, 122)
        lblFinalTotal.Name = "lblFinalTotal"
        lblFinalTotal.Size = New Size(194, 25)
        lblFinalTotal.TabIndex = 8
        lblFinalTotal.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblTax
        ' 
        lblTax.BackColor = SystemColors.ControlLight
        lblTax.BorderStyle = BorderStyle.Fixed3D
        lblTax.Location = New Point(121, 93)
        lblTax.Name = "lblTax"
        lblTax.Size = New Size(194, 25)
        lblTax.TabIndex = 7
        lblTax.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblDiscount
        ' 
        lblDiscount.BackColor = SystemColors.ControlLight
        lblDiscount.BorderStyle = BorderStyle.Fixed3D
        lblDiscount.Location = New Point(121, 63)
        lblDiscount.Name = "lblDiscount"
        lblDiscount.Size = New Size(194, 25)
        lblDiscount.TabIndex = 6
        lblDiscount.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblSubtotal
        ' 
        lblSubtotal.BackColor = SystemColors.ControlLight
        lblSubtotal.BorderStyle = BorderStyle.Fixed3D
        lblSubtotal.Location = New Point(121, 32)
        lblSubtotal.Name = "lblSubtotal"
        lblSubtotal.Size = New Size(194, 25)
        lblSubtotal.TabIndex = 5
        lblSubtotal.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Location = New Point(-2, 154)
        Label13.Name = "Label13"
        Label13.Size = New Size(108, 20)
        Label13.TabIndex = 4
        Label13.Text = "Purchase Level:"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Location = New Point(28, 122)
        Label12.Name = "Label12"
        Label12.Size = New Size(80, 20)
        Label12.TabIndex = 3
        Label12.Text = "Final Total:"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Location = New Point(75, 93)
        Label11.Name = "Label11"
        Label11.Size = New Size(33, 20)
        Label11.TabIndex = 2
        Label11.Text = "Tax:"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(38, 63)
        Label10.Name = "Label10"
        Label10.Size = New Size(70, 20)
        Label10.TabIndex = 1
        Label10.Text = "Discount:"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(38, 32)
        Label9.Name = "Label9"
        Label9.Size = New Size(68, 20)
        Label9.TabIndex = 0
        Label9.Text = "Subtotal:"
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.DarkSeaGreen
        btnClear.Location = New Point(12, 588)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(94, 50)
        btnClear.TabIndex = 5
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.DarkSeaGreen
        btnExit.Location = New Point(135, 582)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(94, 56)
        btnExit.TabIndex = 6
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' btnPrintSummary
        ' 
        btnPrintSummary.BackColor = Color.DarkSeaGreen
        btnPrintSummary.Location = New Point(263, 582)
        btnPrintSummary.Name = "btnPrintSummary"
        btnPrintSummary.Size = New Size(103, 56)
        btnPrintSummary.TabIndex = 7
        btnPrintSummary.Text = "Print " & vbCrLf & "Summary"
        btnPrintSummary.UseVisualStyleBackColor = False
        ' 
        ' btnRemoveItem
        ' 
        btnRemoveItem.BackColor = Color.DarkCyan
        btnRemoveItem.Location = New Point(86, 291)
        btnRemoveItem.Name = "btnRemoveItem"
        btnRemoveItem.Size = New Size(135, 29)
        btnRemoveItem.TabIndex = 11
        btnRemoveItem.Text = "Remove Item"
        btnRemoveItem.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 650)
        Controls.Add(btnPrintSummary)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(GroupBox4)
        Controls.Add(GroupBox3)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox1)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Smart Shopping System"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        GroupBox3.ResumeLayout(False)
        GroupBox4.ResumeLayout(False)
        GroupBox4.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtCustomerName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cboMembership As ListBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtProductName As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cboCategory As ListBox
    Friend WithEvents txtDiscountCode As TextBox
    Friend WithEvents txtQuantity As TextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnCalculateBill As Button
    Friend WithEvents btnAddItem As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents lstCart As ListBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents lblPurchaseLevel As Label
    Friend WithEvents lblFinalTotal As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblDiscount As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnPrintSummary As Button
    Friend WithEvents btnRemoveItem As Button

End Class
