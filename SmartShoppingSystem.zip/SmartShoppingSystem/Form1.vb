﻿Public Class Form1
    ' Global Arrays and Variables 
    Dim itemNames As New List(Of String)
    Dim itemTotals As New List(Of Decimal)
    Const decTAX_RATE As Decimal = 0.08D

    ' --- EVENT HANDLERS ---

    Private Sub btnAddItem_Click(sender As Object, e As EventArgs) Handles btnAddItem.Click

        Try
            If ValidateInput() Then
                Dim name As String = txtProductName.Text
                Dim price As Decimal = Decimal.Parse(txtPrice.Text)
                Dim qty As Integer = Integer.Parse(txtQuantity.Text)

                ' Calculate Item Total 
                Dim total As Decimal = CalculateItemTotal(price, qty)

                ' Store in "Arrays" (List collection used for flexibility) 
                itemNames.Add(name)
                itemTotals.Add(total)

                ' Update ListBox display 
                lstCart.Items.Add($"{name} - {qty} x {price:C} = {total:C}")

                ClearInputFields()
            End If
        Catch ex As Exception
            MessageBox.Show("Error: Please ensure price and quantity are valid numbers.", "Input Error")
        End Try
    End Sub

    Private Sub btnRemoveItem_Click(sender As Object, e As EventArgs) Handles btnRemoveItem.Click
        ' Check if an item is actually selected in the ListBox
        If lstCart.SelectedIndex <> -1 Then
            ' Get the index of the selected item
            Dim index As Integer = lstCart.SelectedIndex

            ' Remove from the data collections first
            itemNames.RemoveAt(index)
            itemTotals.RemoveAt(index)

            ' Remove from the visual ListBox
            lstCart.Items.RemoveAt(index)

            ' Recalculate the bill automatically to update totals
            btnCalculateBill.PerformClick()

            MessageBox.Show("Item removed from cart.", "Update")
        Else
            ' Error handling for no selection
            MessageBox.Show("Please select an item in the cart to remove.", "Selection Required")
        End If
    End Sub

    Private Sub btnCalculateBill_Click(sender As Object, e As EventArgs) Handles btnCalculateBill.Click

        If itemTotals.Count < 3 Then
            MessageBox.Show("Please add at least 3 products.")
            Return
        End If

        Dim subtotal As Decimal = CalculateSubtotal()
        Dim discount As Decimal = CalculateDiscount(subtotal)
        Dim tax As Decimal = (subtotal - discount) * decTAX_RATE
        Dim finalTotal As Decimal = (subtotal - discount) + tax

        ' Display Results with Currency Formatting]
        lblSubtotal.Text = subtotal.ToString("C")
        lblDiscount.Text = discount.ToString("C")
        lblTax.Text = tax.ToString("C")
        lblFinalTotal.Text = finalTotal.ToString("C")

        ' Classify Purchase
        lblPurchaseLevel.Text = GetPurchaseLevel(finalTotal)
    End Sub

    ' --- CUSTOM FUNCTIONS & PROCEDURES ---
    Private Function ValidateInput() As Boolean

        If txtProductName.Text = "" Or txtPrice.Text = "" Or txtQuantity.Text = "" Then
            MessageBox.Show("All fields are required.")
            Return False
        End If

        Dim p As Decimal
        Dim q As Integer
        If Not Decimal.TryParse(txtPrice.Text, p) OrElse p <= 0 Then
            MessageBox.Show("Price must be a positive number.")
            Return False
        End If

        If Not Integer.TryParse(txtQuantity.Text, q) OrElse q < 1 Then
            MessageBox.Show("Quantity must be at least 1.")
            Return False
        End If

        Return True
    End Function

    Private Function CalculateItemTotal(price As Decimal, qty As Integer) As Decimal
        Return price * qty
    End Function

    Private Function CalculateSubtotal() As Decimal
        Dim total As Decimal = 0
        ' Use Loop to process items
        For Each amount In itemTotals
            total += amount
        Next
        Return total
    End Function

    Private Function CalculateDiscount(subtotal As Decimal) As Decimal
        Dim discountPercent As Decimal = 0D
        Dim code As String = txtDiscountCode.Text.ToUpper().Trim() ' Standardize input

        ' 1. Apply Automatic Subtotal Discounts
        If subtotal > 250 Then
            discountPercent = 0.15D ' 15% discount
        ElseIf subtotal > 100 Then
            discountPercent = 0.1D ' 10% discount
        End If

        ' 2. Apply Specific Manual Discount Codes
        ' We use Select Case as suggested in the project doc
        Select Case code
            Case "SAVE10"
                discountPercent += 0.1D
            Case "STUDENT20"
                discountPercent += 0.2D
            Case "OFF30"
                discountPercent += 0.3D
            Case "FRIDAY15"
                discountPercent += 0.15D
            Case ""
                ' No code entered, do nothing
            Case Else
                ' Validation: Warn user if the code is unrecognized 
                MessageBox.Show("Invalid Discount Code entered.", "Validation Error")
        End Select

        ' 3. Apply Membership Discount if applicable 
        If cboMembership.Text = "Member" Then
            discountPercent += 0.05D ' Extra 5% off 
        End If

        ' Return final dollar amount to be deducted
        Return subtotal * discountPercent
    End Function

    Private Function GetPurchaseLevel(total As Decimal) As String

        Select Case total
            Case < 50
                Return "Small Purchase"
            Case 50 To 199.99
                Return "Regular Purchase"
            Case 200 To 499.99
                Return "Large Purchase"
            Case Else
                Return "Premium Purchase"
        End Select
    End Function

    ' --- UTILITY BUTTONS ---

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        itemNames.Clear()
        itemTotals.Clear()
        lstCart.Items.Clear()
        lblSubtotal.Text = "$0.00"
        lblDiscount.Text = "$0.00"
        lblTax.Text = "$0.00"
        lblFinalTotal.Text = "$0.00"
        lblPurchaseLevel.Text = "-"
        ClearInputFields()
    End Sub

    Private Sub ClearInputFields()
        txtProductName.Clear()
        txtPrice.Clear()
        txtQuantity.Clear()
        txtProductName.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnPrintSummary_Click(sender As Object, e As EventArgs) Handles btnPrintSummary.Click
        ' Call the procedure to display the receipt
        DisplayReceipt()
    End Sub

    Private Sub DisplayReceipt()
        ' 1. Use String to build the summary 
        Dim summary As String = "--- SHOPPING RECEIPT ---" & vbCrLf
        summary &= "Date: " & DateTime.Now.ToString("g") & vbCrLf ' Formatting date/time 
        summary &= "Customer: " & txtCustomerName.Text & vbCrLf
        summary &= "--------------------------" & vbCrLf

        ' 2. Use a Loop to list all items from the arrays 
        summary &= "Items Purchased:" & vbCrLf
        For i As Integer = 0 To itemNames.Count - 1
            summary &= $"- {itemNames(i)}: {itemTotals(i):C}" & vbCrLf
        Next

        summary &= "--------------------------" & vbCrLf

        ' 3. Show totals with currency formatting 
        summary &= "Subtotal: " & lblSubtotal.Text & vbCrLf
        summary &= "Discount: " & lblDiscount.Text & vbCrLf
        summary &= "Tax: " & lblTax.Text & vbCrLf
        summary &= "FINAL TOTAL: " & lblFinalTotal.Text & vbCrLf
        summary &= "Status: " & lblPurchaseLevel.Text & vbCrLf
        summary &= "--------------------------" & vbCrLf
        summary &= "Thank you for shopping!"

        ' 4. Display the clear summary of the transaction 
        MessageBox.Show(summary, "Transaction Summary")
    End Sub
End Class